let settings = {
  "exceedancetables2dapi": {
    "use": false,
    "ip": "localhost",
    "port": "8000"
  },
  "scenarios": [
    "Basis"
  ],
  "x-axis": {
    "min": 1,
    "max": 100
  }
}