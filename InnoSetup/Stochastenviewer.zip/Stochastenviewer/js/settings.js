let settings = {
	"x-axis": {
		"min":1,
		"max":100
	}
}
