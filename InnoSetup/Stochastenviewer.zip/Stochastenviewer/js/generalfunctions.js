
 //write a function that converts lat/lon map coordinates to the Dutch RD new system
 function WGS842RD(Lat, Lon) {
    let phiBesLambdaBes = WGS842BESSEL(Lat, Lon);
    let xy = BESSEL2RD(phiBesLambdaBes[0], phiBesLambdaBes[1]);
    return xy;
}

function PopulateDropdownListFromJSON(Name, ArrayIdx){
    let dropdown = document.getElementById(Name);
    dropdown.length = 0;
    
    let defaultOption = document.createElement('option');
    defaultOption.text = 'all';

    dropdown.add(defaultOption);
    dropdown.selectedIndex = 0;

    let option;
    for (let i = 0; i < stochasts.stochasts[ArrayIdx].values.length; i++) {
      option = document.createElement('option');
      option.text = stochasts.stochasts[ArrayIdx].values[i].value;
      option.value = stochasts.stochasts[ArrayIdx].values[i].value;
      dropdown.add(option);
    }
}



function WGS842BESSEL(PhiWGS, LamWGS) {
    let dphi, dlam, phicor, lamcor;

    dphi = PhiWGS - 52;
    dlam = LamWGS - 5;
    phicor = (-96.862 - dphi * 11.714 - dlam * 0.125) * 0.00001;
    lamcor = (dphi * 0.329 - 37.902 - dlam * 14.667) * 0.00001;
    let phi = PhiWGS - phicor;
    let lambda = LamWGS - lamcor;
    return [phi,lambda];
}

function BESSEL2RD(phiBes, lamBes){
    
    //converteert Lat/Long van een Bessel-functie naar X en Y in RD
    //code is geheel gebaseerd op de routines van Ejo Schrama's software:
    //schrama@geo.tudelft.nl
    let d_1, d_2, r, sa, ca, cpsi, spsi;
    let b, dl, w, q;
    let dq, phi, lambda, s2psihalf, cpsihalf, spsihalf;
    let tpsihalf;

    let x0 = 155000;
    let y0 = 463000;
    let k = 0.9999079;
    let bigr = 6382644.571;
    let m = 0.003773953832;
    let n = 1.00047585668;

    let pi = Math.PI;
    let lambda0 = pi * 0.0299313271611111;
    let phi0 = pi * 0.289756447533333;
    let l0 = pi * 0.0299313271611111;
    let b0 = pi * 0.289561651383333;

    let e = 0.08169683122;
    let a = 6377397.155;

    phi = phiBes / 180 * pi;
    lambda = lamBes / 180 * pi;
    q = Math.log(Math.tan(phi / 2 + pi / 4));
    dq = e / 2 * Math.log((e * Math.sin(phi) + 1) / (1 - e * Math.sin(phi)));
    q = q - dq;
    w = n * q + m;
    b = Math.atan(Math.pow(Math.exp(1), w)) * 2 - pi / 2;
    dl = n * (lambda - lambda0);
    d_1 = Math.sin((b - b0) / 2);
    d_2 = Math.sin(dl / 2);
    s2psihalf = d_1 * d_1 + d_2 * d_2 * Math.cos(b) * Math.cos(b0);
    cpsihalf = Math.sqrt(1 - s2psihalf);
    spsihalf = Math.sqrt(s2psihalf);
    tpsihalf = spsihalf / cpsihalf;
    spsi = spsihalf * 2 * cpsihalf;
    cpsi = 1 - s2psihalf * 2;
    sa = Math.sin(dl) * Math.cos(b) / spsi;
    ca = (Math.sin(b) - Math.sin(b0) * cpsi) / (Math.cos(b0) * spsi);
    r = k * 2 * bigr * tpsihalf;
    let X = Math.round(r * sa + x0);
    let Y = Math.round(r * ca + y0);
    return [X,Y];
}

function getAngle(latLng1, latLng2, coef) {
    var dy = latLng2.lat - latLng1.lat;
    var dx = Math.cos(Math.PI / 180 * latLng1.lat) * (latLng2.lng - latLng1.lng);
    var ang = ((Math.atan2(dy, dx) / Math.PI) * 180 * coef);
    return (ang).toFixed(2);
}

function distanceTo(p1, p2) {
    var x = p2.x - p1.x,
        y = p2.y - p1.y;

    return Math.sqrt(x * x + y * y);
}

function toPoint(x, y, round) {
    if (x instanceof Point) {
        return x;
    }
    if (x.isArray()) {
        return new Point(x[0], x[1]);
    }
    if (x === undefined || x === null) {
        return x;
    }
    if (typeof x === 'object' && 'x' in x && 'y' in x) {
        return new Point(x.x, x.y);
    }
    return new Point(x, y, round);
}

function Point(x, y, round) {
    this.x = (round ? Math.round(x) : x);
    this.y = (round ? Math.round(y) : y);
}

function interpolate(x1, y1, x2, y2, x3){
    //this function interpolates between two xy value pairs. 
    //note: it does NOT extrapolate
    if (x3 <= x1) {
        return y1;
    } else if (x3 >= x2) {
        return y2;
    } else {
        return y1 + (y2 - y1)/(x2- x1)*(x3 - x1);
    }
}

function interpolateRGB(x1, R1, G1, B1, x2, R2, G2, B2, x3){
    let R = Math.round(interpolate(x1, R1, x2, R2, x3),0);
    let G = Math.round(interpolate(x1, G1, x2, G2, x3),0);
    let B = Math.round(interpolate(x1, B1, x2, B2, x3),0);
    return 'rgb(' + R + ',' + G + ',' + B +')';
}

//#########################################################################//
//snippet from https://gist.github.com/IceCreamYou/6ffa1b18c4c8f6aeaad2    //
// Returns the value at a given percentile in a sorted numeric array.
// "Linear interpolation between closest ranks" method
//#########################################################################//
function percentile(arr, p) {
    if (arr.length === 0) return 0;
	arr.sort(function(a, b){return a - b});	//sorting numeric in ascending order
    if (typeof p !== 'number') throw new TypeError('p must be a number');
    if (p <= 0) return arr[0];
    if (p >= 1) return arr[arr.length - 1];

    var index = (arr.length - 1) * p,
        lower = Math.floor(index),
        upper = lower + 1,
        weight = index % 1;

    if (upper >= arr.length) return arr[lower];
    return arr[lower] * (1 - weight) + arr[upper] * weight;
}

// Returns the percentile of the given value in a sorted numeric array.
function percentRank(arr, v) {
    if (typeof v !== 'number') throw new TypeError('v must be a number');
    for (var i = 0, l = arr.length; i < l; i++) {
        if (v <= arr[i]) {
            while (i < l && v === arr[i]) i++;
            if (i === 0) return 0;
            if (v !== arr[i-1]) {
                i += (v - arr[i-1]) / (arr[i] - arr[i-1]);
            }
            return i / l;
        }
    }
    return 1;
}
//#########################################################################//

