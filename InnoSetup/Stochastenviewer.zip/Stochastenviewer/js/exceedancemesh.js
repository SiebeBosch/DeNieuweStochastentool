let Mesh = 
   {
        "type": "FeatureCollection",
        "name":  "test",
        "timesteps": 0,
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84"} },
        "features": [
        ]
   }
