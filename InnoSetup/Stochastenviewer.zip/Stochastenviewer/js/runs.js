let runs = {
	"scenarios":[
      {
    	"ID":"Basis",
        "runs": [
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_40mm_Normaal_ruw_faalt_niet_bagger","runidx":0,"seizoen":"zomer","volume":"40","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_60mm_Normaal_ruw_faalt_niet_bagger","runidx":1,"seizoen":"zomer","volume":"60","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_80mm_Normaal_ruw_faalt_niet_bagger","runidx":2,"seizoen":"zomer","volume":"80","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_100mm_Normaal_ruw_faalt_niet_bagger","runidx":3,"seizoen":"zomer","volume":"100","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_120mm_Normaal_ruw_faalt_niet_bagger","runidx":4,"seizoen":"zomer","volume":"120","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_zomer_MIDDELNAT_MIDDELHOOG_140mm_Normaal_ruw_faalt_niet_bagger","runidx":5,"seizoen":"zomer","volume":"140","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_40mm_Normaal_ruw_faalt_niet_bagger","runidx":6,"seizoen":"winter","volume":"40","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_60mm_Normaal_ruw_faalt_niet_bagger","runidx":7,"seizoen":"winter","volume":"60","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_80mm_Normaal_ruw_faalt_niet_bagger","runidx":8,"seizoen":"winter","volume":"80","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_100mm_Normaal_ruw_faalt_niet_bagger","runidx":9,"seizoen":"winter","volume":"100","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_120mm_Normaal_ruw_faalt_niet_bagger","runidx":10,"seizoen":"winter","volume":"120","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""},
          {"runid":"STOWA2024_HUIDIG_winter_MIDDELNAT_MIDDELHOOG_140mm_Normaal_ruw_faalt_niet_bagger","runidx":11,"seizoen":"winter","volume":"140","patroon":"MIDDELHOOG","gw":"MIDDELNAT","boundary":"Normaal","wind":"","extra1":"ruw","extra2":"faalt_niet","extra3":"bagger","extra4":""}
        ]		  
	  }
	]
};
