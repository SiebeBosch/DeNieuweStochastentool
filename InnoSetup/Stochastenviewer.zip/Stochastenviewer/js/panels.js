
  function openLeftPanel() {
    document.getElementById("leftpanel").style.width = "250px";
    document.getElementById("openLeftPanel").style.visibility = "hidden";
  }
  function closeLeftPanel() {
    document.getElementById("leftpanel").style.width = "0";
    document.getElementById("openLeftPanel").style.visibility = "visible";
  }
  function openRightPanel() {
    document.getElementById("rightpanel").classList.remove('closed');
  }
  function closeRightPanel() {
    document.getElementById("rightpanel").classList.add('closed');
  }
