PointAndMarker.marker.on('click', async (e) => {
    let data = getExceedanceData(item.ID);
    openRightPanel();
    let centerxy = WGS842RD(item.lat, item.lon);
    console.log("awaiting elevation data...");
    await getElevationPercentiles(item, centerxy, 10, [0.05, 0.95]);
    console.log("elevation data complete...");
    window.selectedItem = item;
    window.selectedData = data;
    
    // Add this line to update parameter buttons
    updateParameterButtons(item.ID);
    
    setChartData();
}); 