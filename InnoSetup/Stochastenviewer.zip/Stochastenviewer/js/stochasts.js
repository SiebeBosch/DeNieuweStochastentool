let stochasts = {
    "stochasts": [
      {"name": "Seizoen", "values": [
        {"value": "zomer"},
        {"value": "winter"}
      ]
    },
      {"name": "Volume", "values": [
        {"value": "40"},
        {"value": "75"},
        {"value": "100"},
        {"value": "120"},
        {"value": "140"},
        {"value": "60"},
        {"value": "95"}
      ]
    },
      {"name": "Patroon", "values": [
        {"value": "MIDDELHOOG"}
      ]
    },
      {"name": "Init", "values": [
        {"value": "MIDDELNAT"}
      ]
    },
      {"name": "Boundary", "values": [
        {"value": ""}
      ]
    },
      {"name": "Wind", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra1", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra2", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra3", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra4", "values": [
        {"value": ""}
      ]
    }
    ]
}
