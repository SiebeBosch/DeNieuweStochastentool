let stochasts = {
    "stochasts": [
      {"name": "Seizoen", "values": [
        {"value": "zomer"},
        {"value": "winter"}
      ]
    },
      {"name": "Volume", "values": [
        {"value": "30"},
        {"value": "40"},
        {"value": "50"},
        {"value": "60"},
        {"value": "70"},
        {"value": "80"},
        {"value": "90"},
        {"value": "100"},
        {"value": "110"},
        {"value": "120"},
        {"value": "140"}
      ]
    },
      {"name": "Patroon", "values": [
        {"value": "MIDDELHOOG"},
        {"value": "LAAG"},
        {"value": "KORT"}
      ]
    },
      {"name": "Init", "values": [
        {"value": "NAT"},
        {"value": "MIDDELNAT"}
      ]
    },
      {"name": "Boundary", "values": [
        {"value": ""},
        {"value": "Normaal"}
      ]
    },
      {"name": "Wind", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra1", "values": [
        {"value": "Ruw_Slib"},
        {"value": "ruw"}
      ]
    },
      {"name": "Extra2", "values": [
        {"value": "Normaal"},
        {"value": "faalt_niet"}
      ]
    },
      {"name": "Extra3", "values": [
        {"value": ""},
        {"value": "bagger"}
      ]
    },
      {"name": "Extra4", "values": [
        {"value": ""}
      ]
    }
    ]
}
