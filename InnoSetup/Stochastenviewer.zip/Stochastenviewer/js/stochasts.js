let stochasts = {
    "stochasts": [
      {"name": "Seizoen", "values": [
        {"value": "zomer"},
        {"value": "winter"}
      ]
    },
      {"name": "Volume", "values": [
        {"value": "45"},
        {"value": "55"},
        {"value": "65"},
        {"value": "75"},
        {"value": "90"},
        {"value": "100"},
        {"value": "110"},
        {"value": "125"},
        {"value": "130"},
        {"value": "145"},
        {"value": "160"},
        {"value": "35"},
        {"value": "40"},
        {"value": "50"},
        {"value": "60"},
        {"value": "70"},
        {"value": "80"},
        {"value": "85"},
        {"value": "95"},
        {"value": "105"}
      ]
    },
      {"name": "Patroon", "values": [
        {"value": "HOOG"},
        {"value": "MIDDELHOOG"},
        {"value": "LAAG"},
        {"value": "KORT"}
      ]
    },
      {"name": "Init", "values": [
        {"value": "SMDROOG"},
        {"value": "SMMIDDEL"},
        {"value": "SMNAT"}
      ]
    },
      {"name": "Boundary", "values": [
        {"value": "Gemiddeld"},
        {"value": "T_100"},
        {"value": "T_5"}
      ]
    },
      {"name": "Wind", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra1", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra2", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra3", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra4", "values": [
        {"value": ""}
      ]
    }
    ]
}
