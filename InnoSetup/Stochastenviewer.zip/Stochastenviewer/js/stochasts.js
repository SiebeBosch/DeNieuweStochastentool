let stochasts = {
    "stochasts": [
      {"name": "Seizoen", "values": [
        {"value": "zomer"},
        {"value": "winter"}
      ]
    },
      {"name": "Volume", "values": [
        {"value": "20"},
        {"value": "30"},
        {"value": "40"},
        {"value": "50"},
        {"value": "60"},
        {"value": "70"},
        {"value": "80"},
        {"value": "90"},
        {"value": "100"}
      ]
    },
      {"name": "Patroon", "values": [
        {"value": "MIDDELHOOG"},
        {"value": "LAAG"},
        {"value": "KORT"}
      ]
    },
      {"name": "Init", "values": [
        {"value": "nat"},
        {"value": "middelnat"},
        {"value": "middeldroog"}
      ]
    },
      {"name": "Boundary", "values": [
        {"value": "0xHHW_geen_verhoging_Amplitude"},
        {"value": "1xHHW_een_maalstop_Amplitude"},
        {"value": "1xHHW_extreem_Amplitude"},
        {"value": "1xHHW_twee_maalstops_Amplitude"}
      ]
    },
      {"name": "Wind", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra1", "values": [
        {"value": "Ruwheid"}
      ]
    },
      {"name": "Extra2", "values": [
        {"value": "Restart"}
      ]
    },
      {"name": "Extra3", "values": [
        {"value": ""}
      ]
    },
      {"name": "Extra4", "values": [
        {"value": ""}
      ]
    }
    ]
}
