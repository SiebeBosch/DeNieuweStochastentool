
function initializeMap() {
  L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
  }).addTo(backgroundLayerGroup);
}

function plotBackgroundMap(bg) {
  backgroundLayerGroup.clearLayers();
  if (bg == 'OSM') {
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/streets-v11',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
    }).addTo(backgroundLayerGroup);

  } else if (bg == 'LUFO') {
	let wmsLayer = L.tileLayer.wms('https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0?', {
      layers: 'Actueel_ortho25'
    }).addTo(backgroundLayerGroup);
  }
}

function plotPeilgebieden() {
  let pgStyle = {
    "fillColor": "#15617a",
    "fillOpacity": 0.65,
    "color": "#1b3d47",
    "weight": 1,
    "opacity": 1
  };
  if (document.getElementById("peilgebieden").checked) {
    L.geoJson(subcatchments, { style: pgStyle }).addTo(featureLayerGroup);
  } else {
    featureLayerGroup.clearLayers();
  };
}


function plotMarkers() {
  markerLayerGroup.clearLayers();
  pointsAndMarkers.forEach(plotMarker);
}

function plotMarker(item, index) {
  item.marker.addTo(markerLayerGroup);
}