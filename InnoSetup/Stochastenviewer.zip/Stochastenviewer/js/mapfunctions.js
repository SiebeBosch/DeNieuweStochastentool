
function initializeMap() {
  L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
  }).addTo(backgroundLayerGroup);
}

function plotBackgroundMap(bg) {
  backgroundLayerGroup.clearLayers();
  if (bg == 'OSM') {
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/streets-v11',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
    }).addTo(backgroundLayerGroup);
  } else if (bg == 'LUFO') {
    let wmsLayer = L.tileLayer.wms('https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0?', {
      layers: 'Actueel_ortho25'
    }).addTo(backgroundLayerGroup);
  } else if (bg == 'OSM_DARK') {
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/dark-v10',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
    }).addTo(backgroundLayerGroup);

  }
}

function plotPeilgebieden() {
  let pgStyle = {
    "fillColor": "#15617a",
    "fillOpacity": 0.65,
    "color": "#1b3d47",
    "weight": 1,
    "opacity": 1
  };
  if (document.getElementById("peilgebieden").checked) {
    L.geoJson(subcatchments, { style: pgStyle }).addTo(featureLayerGroup);
  } else {
    featureLayerGroup.clearLayers();
  };
}

function plotExceedanceMesh(returnPeriod) {
  // Function to dynamically set the style for each cell based on its return period value
  meshLayerGroup.clearLayers();

  function style(feature) {
    // Define a base color; this could be made more sophisticated with a color scale
    let color = '#999999'; // Default color
    let fillOpacity = 0.7; // Default fill opacity
    const value = feature.properties[returnPeriod];

    // Example of setting color based on the return period value; adjust thresholds and colors as needed
    if (value < 0.05) {
      fillOpacity = 0;
    } else if (value < 0.25) {
      color = '#87CEFA';
    } else if (value < 0.5) {
      color = '#00BFFF';
    } else if (value < 0.75) {
      color = '#1E90FF';
    } else if (value < 1.00) {
      color = '#6495ED';
    } else if (value < 1.50) {
      color = '#4169E1';
    } else {
      color = '#000080';
    }

    return {
      fillColor: color,
      weight: 0,
      opacity: 1,
      fillOpacity: fillOpacity
    };
  }


  // Function to add interaction to each cell
  function onEachFeature(feature, layer) {
    // Tooltip content
    const tooltipContent = `<div class="tooltip">Depth:<br>T=10: ${Math.round(feature.properties.T10 * 100) / 100} m<br>T=25: ${Math.round(feature.properties.T25 * 100) / 100} m<br>T=50: ${Math.round(feature.properties.T50 * 100) / 100} m<br>T=100: ${Math.round(feature.properties.T100 * 100) / 100} m</div>`;

    // Bind the tooltip to the layer
    layer.bindTooltip(tooltipContent, {
      // Tooltip options, adjust as needed
      permanent: false, // Tooltip will only show on hover
      direction: 'auto', // Automatically position the tooltip
      className: 'custom-tooltip', // Custom CSS class for styling
      sticky: true // Tooltip follows the mouse
    });

    // Click event listener, remains unchanged
    layer.on('click', async function (e) {
      //alert("Value for " + returnPeriod + ": " + feature.properties[returnPeriod]);
      let data = getExceedanceData2D(feature.properties.idx);

      //we'll construct our data in the same format as for 1D objects
      let item = {};
      item.ID = "Cel index " + feature.properties.idx;
      item.lat = feature.geometry.coordinates[0][0][1];
      item.lon = feature.geometry.coordinates[0][0][0];
      item.WP = null;
      item.ZP = null;
      item.T10 = feature.T10;
      item.T25 = feature.T25;
      item.T50 = feature.T50;
      item.T100 = feature.T100;
      item.mv5pct = null;
      item.mv95pct = null;
      
      openRightPanel();
      let centerxy = WGS842RD(feature.geometry.coordinates[0][0][0], feature.geometry.coordinates[0][0][1]);
      //here we are dealing with an asychronous request, so all other actions must wait until the surface levels have been successfully retrieved
      console.log("awaiting elevation data...");
      //await getElevationPercentiles(item, centerxy, 10, [0.05, 0.95]);
      feature.mv5pct = 0;
      feature.mv95pct = 1;

      console.log("elevation data complete...");
      window.selectedItem = item;
      window.selectedData = data;

      console.log("selectedItem is ", window.selectedItem);
      console.log("selectedData is ", window.selectedData);

      setChartData();
    });
  }

  // Check if the mesh should be added to the map
  if (document.getElementById("exceedanceMeshCheckbox").checked) {
    L.geoJson(Mesh, {
      style: style,
      onEachFeature: onEachFeature
    }).addTo(meshLayerGroup);
  } else {
    meshLayerGroup.clearLayers();
  }
}



function plotMarkers() {
  markerLayerGroup.clearLayers();
  pointsAndMarkers.forEach(plotMarker);
}

function plotMarker(item, index) {
  item.marker.addTo(markerLayerGroup);
}