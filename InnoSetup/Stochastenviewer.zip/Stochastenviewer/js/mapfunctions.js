
function initializeMap() {
  L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
  }).addTo(backgroundLayerGroup);
}

function plotBackgroundMap(bg) {
  backgroundLayerGroup.clearLayers();
  if (bg == 'OSM') {
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/streets-v11',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
    }).addTo(backgroundLayerGroup);
  } else if (bg == 'LUFO') {
    let wmsLayer = L.tileLayer.wms('https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0?', {
      layers: 'Actueel_ortho25'
    }).addTo(backgroundLayerGroup);
  } else if (bg == 'OSM_DARK') {
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 18,
      id: 'mapbox/dark-v10',
      tileSize: 512,
      zoomOffset: -1,
      accessToken: 'pk.eyJ1Ijoic2llYmVib3NjaCIsImEiOiJjazh1NnBqdDIwMW92M3FrZDF6YmNndDMyIn0.7J3-b577pBYCg1XWhmejXA'
    }).addTo(backgroundLayerGroup);

  }
}

function plotPeilgebieden() {
  let pgStyle = {
    "fillColor": "#15617a",
    "fillOpacity": 0.65,
    "color": "#1b3d47",
    "weight": 1,
    "opacity": 1
  };
  if (document.getElementById("peilgebieden").checked) {
    L.geoJson(subcatchments, { style: pgStyle }).addTo(featureLayerGroup);
  } else {
    featureLayerGroup.clearLayers();
  };
}

function plotExceedanceMesh(returnPeriod) {
  // Function to dynamically set the style for each cell based on its return period value
  meshLayerGroup.clearLayers();

  function style(feature) {
    // Define a base color; this could be made more sophisticated with a color scale
    let color = '#999999'; // Default color
    let fillOpacity = 0.7; // Default fill opacity
    const value = feature.properties[returnPeriod];

    // Example of setting color based on the return period value; adjust thresholds and colors as needed
    if (value < 0.05) {
      fillOpacity = 0;
    } else if (value < 0.25) {
      color = '#87CEFA';
    } else if (value < 0.5) {
      color = '#00BFFF';
    } else if (value < 0.75) {
      color = '#1E90FF';
    } else if (value < 1.00) {
      color = '#6495ED';
    } else if (value < 1.50) {
      color = '#4169E1';
    } else {
      color = '#000080';
    }

    return {
      fillColor: color,
      weight: 0,
      opacity: 1,
      fillOpacity: fillOpacity
    };
  }


  // Function to add interaction to each cell
  function onEachFeature(feature, layer) {
    // Tooltip content
    const tooltipContent = `<div class="tooltip">Depth:<br>T=10: ${Math.round(feature.properties.T10 * 100) / 100} m<br>T=25: ${Math.round(feature.properties.T25 * 100) / 100} m<br>T=50: ${Math.round(feature.properties.T50 * 100) / 100} m<br>T=100: ${Math.round(feature.properties.T100 * 100) / 100} m</div>`;

    // Bind the tooltip to the layer
    layer.bindTooltip(tooltipContent, {
      // Tooltip options, adjust as needed
      permanent: false, // Tooltip will only show on hover
      direction: 'auto', // Automatically position the tooltip
      className: 'custom-tooltip', // Custom CSS class for styling
      sticky: true // Tooltip follows the mouse
    });

    layer.on('click', function (e) {
      let allScenarioData = getExceedanceData2D(feature.properties.idx);

      let item = {
        ID: "Cel index " + feature.properties.idx,
        lat: feature.geometry.coordinates[0][0][1],
        lon: feature.geometry.coordinates[0][0][0],
        WP: null,
        ZP: null,
        T10: feature.properties.T10,
        T25: feature.properties.T25,
        T50: feature.properties.T50,
        T100: feature.properties.T100,
        mv5pct: 0,
        mv95pct: 1
      };

      openRightPanel();

      console.log("selectedItem is ", item);
      console.log("selectedData is ", allScenarioData);

      window.selectedItem = item;
      window.selectedData = allScenarioData;

      setChartData();
    });
  }

  // Check if the mesh should be added to the map
  if (document.getElementById("exceedanceMeshCheckbox").checked) {
    L.geoJson(Mesh, {
      style: style,
      onEachFeature: onEachFeature
    }).addTo(meshLayerGroup);
  } else {
    meshLayerGroup.clearLayers();
  }
}



function plotMarkers() {
  markerLayerGroup.clearLayers();
  pointsAndMarkers.forEach(plotMarker);
}

function plotMarker(item, index) {
  item.marker.addTo(markerLayerGroup);
}