function clearAndInitializeChart() {
    // Get the canvas element
    const canvas = document.getElementById('chart');
    
    // Clear the canvas by removing and re-adding it
    const parent = canvas.parentNode;
    const newCanvas = document.createElement('canvas');
    newCanvas.id = 'chart';
    parent.removeChild(canvas);
    parent.appendChild(newCanvas);
    
    const ctx = newCanvas.getContext('2d');
    
    // Initialize new chart with scatter plot type
    window.chart = new Chart(ctx, {
        type: 'scatter',
        data: {
            datasets: []
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                intersect: false,
                mode: 'nearest'
            },
            scales: {
                x: {
                    type: 'logarithmic',
                    display: true,
                    title: {
                        display: true,
                        text: 'Time'
                    },
                    ticks: {
                        callback: function(value, index, values) {
                            return Number(value.toString());
                        }
                    },
                    min: 0.1,
                    max: 1000
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Value'
                    }
                }
            },
            plugins: {
                legend: false,
                tooltip: {
                    enabled: true,
                    position: 'nearest',
                    yAlign: 'top',
                    xAlign: 'left',
                    callbacks: {
                        title: function(tooltipItems) {
                            const item = tooltipItems[0];
                            return `${item.dataset.label}: (${item.parsed.x.toFixed(2)}, ${item.parsed.y.toFixed(2)})`;
                        },
                        label: function(context) {
                            const point = context.raw;
                            if (!point.stochasts) return null;
                            
                            // Filter out null, undefined, empty string values, and runid
                            return Object.entries(point.stochasts)
                                .filter(([key, value]) => {
                                    return key !== 'runid' && 
                                           value !== null && 
                                           value !== undefined && 
                                           value !== "";
                                })
                                .map(([key, value]) => {
                                    return `${key}: ${value}`;
                                });
                        },
                        labelTextColor: function(context) {
                            return '#ffffff';  // Make text white for better visibility
                        }
                    }
                }
            }
        }
    });

    // Force remove any existing legend containers
    const legendElements = document.getElementsByClassName('chartjs-legend');
    while(legendElements.length > 0){
        legendElements[0].parentNode.removeChild(legendElements[0]);
    }
}

// Update the addScenarioColoredDatasets function to include stochasts in point data
function addScenarioColoredDatasets(parameter) {
    console.log("coloring by scenario: ", parameter);

    if (!window.chart || !window.chart.data) {
        console.error("Chart not properly initialized");
        return;
    }

    window.selectedData.forEach((scenario, index) => {
        console.log("scenario data is : ", scenario.data[parameter]);

        if (!scenario.data[parameter]) {
            console.warn(`No ${parameter} data found for scenario ${scenario.scenarioID}`);
            return;
        }

        const color = getScenarioColor(index);
        console.log("scenario color set to ", color);

        console.log("populating dataset for ", scenario.scenarioID);
        const mappedData = scenario.data[parameter].map(point => ({
            x: point.x,
            y: point.y,
            stochasts: point.stochasts // Include the stochasts data
        }));
        console.log("Dataset is ", mappedData);

        const dataset = {
            label: `Scenario ${scenario.scenarioID}`,
            data: mappedData,
            borderColor: color,
            backgroundColor: color,
            pointRadius: 3,
            pointHoverRadius: 8,
        };

        window.chart.data.datasets.push(dataset);
    });
    
    window.chart.update();
}

// Update the addStochastColoredDatasets function to include stochasts in point data
function addStochastColoredDatasets(stochast, parameter) {
    const stochastValues = new Set();
    const dataByStochast = new Map();
    
    window.stochastColorMap = new Map();

    console.log("Starting stochast grouping for:", stochast);
    console.log("Parameter:", parameter);

    const stochastKey = stochast.toUpperCase();

    window.selectedData.forEach((scenario, scenarioIndex) => {
        console.log(`Processing scenario ${scenarioIndex}:`, scenario.scenarioID);
        
        if (!scenario.data[parameter]) {
            console.warn(`No ${parameter} data found for scenario ${scenario.scenarioID}`);
            return;
        }

        scenario.data[parameter].forEach((point, pointIndex) => {
            const stochastValue = point.stochasts[stochastKey];
            
            if (stochastValue === undefined || stochastValue === "") {
                return;
            }

            stochastValues.add(stochastValue);

            if (!dataByStochast.has(stochastValue)) {
                dataByStochast.set(stochastValue, []);
            }
            dataByStochast.get(stochastValue).push({
                x: point.x,
                y: point.y,
                stochasts: point.stochasts // Include all stochasts data
            });
        });
    });

    Array.from(stochastValues).sort().forEach((value, index) => {
        if (value === undefined) {
            console.warn("Skipping undefined stochast value");
            return;
        }

        const color = getStochastColor(index, stochastValues.size);
        window.stochastColorMap.set(value.toLowerCase(), color);

        const dataset = {
            label: `${stochast}: ${value}`,
            data: dataByStochast.get(value),
            borderColor: color,
            backgroundColor: color,
            pointRadius: 3,
            pointHoverRadius: 8
        };

        console.log(`Creating dataset for ${value} with ${dataByStochast.get(value).length} points`);
        window.chart.data.datasets.push(dataset);
    });
    
    console.log("Stochast color map:", window.stochastColorMap);
    window.chart.update();
}

function setChartData(parameter = 'waterlevel') {
    const stochast = document.querySelector("#ddlStochast").value.toLowerCase();
    document.getElementById("grafiektitel").innerHTML = `${window.selectedItem.ID} - ${parameter}`;

    clearAndInitializeChart();

    // Get all available parameters from the first scenario's data
    const availableParameters = window.selectedData.length > 0 
        ? Object.keys(window.selectedData[0].data)
        : [];

    // Add constant lines if they exist for this parameter
    if (hasConstantLines(parameter)) {
        addConstantLines(parameter);
    }

    console.log("Number of scenarios: ", window.selectedData.length);

    if (!stochast) {
        addScenarioColoredDatasets(parameter);
    } else {
        addStochastColoredDatasets(stochast, parameter);
    }

    updateChartYAxisBounds();

    console.log("Generating legend");
    generateLegend();
    
    console.log("generating buttons?");
    generateButtons();
}

// Helper function to check if a parameter should have constant lines
function hasConstantLines(parameter) {
    // Add more parameters that should have constant lines as needed
    const parametersWithConstants = ['waterlevel'];
    return parametersWithConstants.includes(parameter);
}

function getScenarioColor(index) {
    // Define a set of distinct colors for different scenarios
    const colors = [
        '#1f77b4', // blue
        '#ff7f0e', // orange
        '#2ca02c', // green
        '#d62728', // red
        '#9467bd', // purple
        '#8c564b', // brown
        '#e377c2', // pink
        '#7f7f7f', // gray
        '#bcbd22', // yellow-green
        '#17becf'  // cyan
    ];
    
    // If we have more scenarios than colors, cycle through the colors
    return colors[index % colors.length];
}

function getStochastColor(index, totalValues) {
    // For stochasts, we'll use a gradient based on the total number of values
    const hue = (index / totalValues) * 360; // Spread hues across 360 degrees
    return `hsl(${hue}, 70%, 50%)`; // Use HSL for even color distribution
}

function updateChartYAxisBounds() {
    const datasets = window.chart.data.datasets;
    if (datasets.length === 0) return;

    let minY = Infinity;
    let maxY = -Infinity;

    datasets.forEach(dataset => {
        dataset.data.forEach(point => {
            minY = Math.min(minY, point.y);
            maxY = Math.max(maxY, point.y);
        });
    });

    // Add some padding to the bounds
    const padding = (maxY - minY) * 0.1;
    window.chart.options.scales.y.min = minY - padding;
    window.chart.options.scales.y.max = maxY + padding;
    window.chart.update();
}

function generateButtons() {
    console.log('generating buttons');
    
    // Get reference to the button panel
    const buttonPanel = document.getElementById('buttonpanel');
    console.log('Button panel found:', buttonPanel);
    
    // Clear any existing buttons
    buttonPanel.innerHTML = '';
    
    // Get available parameters from the first scenario's data if it exists
    let parameters = [];
    if (window.selectedData && window.selectedData.length > 0) {
        const availableParams = Object.keys(window.selectedData[0].data);
        parameters = availableParams.map(param => ({
            id: param,
            label: param.charAt(0).toUpperCase() + param.slice(1)
        }));
    }

    console.log('Parameters to create buttons for:', parameters);

    // Create and append buttons
    parameters.forEach((param, index) => {
        const button = document.createElement('button');
        button.textContent = param.label;
        button.className = 'chartbutton';
        button.setAttribute('data-param', param.id);
        
        button.onclick = function() {
            console.log('Clicked button:', this.textContent);
            
            // Get all buttons and update their styles
            const allButtons = buttonPanel.getElementsByClassName('chartbutton');
            console.log('Found buttons:', allButtons.length);
            
            Array.from(allButtons).forEach(btn => {
                if (btn === this) {
                    console.log('Activating button:', btn.textContent);
                    btn.style.setProperty('border-width', '2px', 'important');
                    btn.style.setProperty('box-shadow', 'rgb(153, 153, 153) 2px 3px 2px', 'important');
                } else {
                    console.log('Deactivating button:', btn.textContent);
                    btn.style.setProperty('border-width', '1px', 'important');
                    btn.style.setProperty('box-shadow', 'none', 'important');
                }
            });
            
            // Update chart
            setChartData(param.id);
        };
        
        // Set initial styles
        if (index === 0) {
            button.style.setProperty('border-width', '2px', 'important');
            button.style.setProperty('box-shadow', 'rgb(153, 153, 153) 2px 3px 2px', 'important');
        } else {
            button.style.setProperty('border-width', '1px', 'important');
            button.style.setProperty('box-shadow', 'none', 'important');
        }
        
        buttonPanel.appendChild(button);
        console.log('Added button:', button.textContent);
    });

    const finalButtons = buttonPanel.getElementsByClassName('chartbutton');
    console.log('Final button count:', finalButtons.length);
    Array.from(finalButtons).forEach(btn => {
        console.log('Button:', btn.textContent, 'Style:', btn.style.cssText);
    });
}