// Application Configuration
const CONFIG = {
    map: {
        defaultView: {
            lat: 52.1,
            lng: 5.988751316,
            zoom: 8
        },
        layers: {
            background: {
                OSM: {
                    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    attribution: '© OpenStreetMap contributors'
                },
                // Add other layer configurations
            }
        }
    },
    chart: {
        defaults: {
            lineColors: {
                winterstreefpeil: 'rgba(50, 84, 168, 1)',
                zomerstreefpeil: 'rgba(242, 183, 56, 1)',
                maaiveld5: 'rgba(96, 209, 104, 1)',
                maaiveld95: 'rgba(60, 133, 65, 1)'
            }
        }
    },
    api: {
        elevation: {
            baseUrl: 'https://ahn.arcgisonline.nl/arcgis/rest/services/Geoprocessing/Profile_AHN3/GPServer/Profile/execute'
        }
    }
};

// Export configuration
window.APP_CONFIG = CONFIG; 