# Stochastenviewer

Auteur: Siebe Bosch<br/><br/>
Deze applicatie bevat een webviewer voor de uitkomsten van stochastenanalyses; in het bijzonder die van De Nieuwe Stochastentool van Hydroconsult.<br/>
Inbegrepen bij de applicatie zijn: demodata van het gebied Duiveland (Waterschap Zeeuwse Eilanden).
De data zijn opgeslagen in JSON-formaat binnen javascript-variabelen. Zie locations.js, results.js en exceedancedata.js.<br/>
<br/>
De applicatie heeft een kaartcomponent (Leaflet) waarop locaties worden geplot in de vorm van ronde markers. Door op een marker te klikken wordt het rechterpaneel geopend, waarin de overschrijdingsgrafiek (exceedance chart) van het onderhavige punt wordt getoond.
<br/>
Er zijn twee viewers:
- index.html. Dit is de basisviewer waarmee peilstijging tov streefpeil wordt geplot voor de herhalingstijden T10, T25, T50 en T100
- invloedsgebied.html. Dit is een geavanceerde viewer waarin het invloedsgebied van een te kiezen deelselectie van stochasten wordt geplot
<br/>

Stochastenviewer is geschreven in puur HTML, CSS en Javascript (IE6). <br/>
Dit maakt hem extreem eenvoudig implementeerbaar op willekeurige webservers of als lokale viewer.
<br/>
De applicatie opstarten
- dubbelklik index.html of invloedsgebieden.html

